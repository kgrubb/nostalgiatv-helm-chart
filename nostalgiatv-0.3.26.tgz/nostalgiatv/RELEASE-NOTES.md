## [0.3.26] - 2026-11-15

### Fixed
- bump NostalgiaTV app image to 0.10.61-20261114-0622

