## [0.3.27] - 2026-11-17

### Fixed
- bump NostalgiaTV app image to 0.10.63-20261116-0440

