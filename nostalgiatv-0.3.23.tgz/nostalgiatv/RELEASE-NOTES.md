## [0.3.23] - 2026-11-07

### Fixed
- bump NostalgiaTV app image to 0.10.56-20261107-0217

