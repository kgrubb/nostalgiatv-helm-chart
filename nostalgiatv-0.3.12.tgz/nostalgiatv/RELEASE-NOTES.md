## [0.3.12] - 2026-10-24

### Fixed
- bump NostalgiaTV app image to 0.10.33-20261023-1717

