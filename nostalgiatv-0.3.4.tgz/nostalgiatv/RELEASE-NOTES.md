## [0.3.4] - 2026-10-05

### Fixed
- bump NostalgiaTV app image to 0.10.21-20261005-1347

