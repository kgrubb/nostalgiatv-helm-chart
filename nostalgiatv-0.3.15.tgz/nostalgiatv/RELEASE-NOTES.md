## [0.3.15] - 2026-10-28

### Fixed
- bump NostalgiaTV app image to 0.10.39-20261027-2330

