## [0.3.16] - 2026-10-29

### Fixed
- bump NostalgiaTV app image to 0.10.40-20261028-1418

