## [0.3.8] - 2026-10-17

### Fixed
- bump NostalgiaTV app image to 0.10.27-20261016-0330

