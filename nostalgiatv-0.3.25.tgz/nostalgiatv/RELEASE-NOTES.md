## [0.3.25] - 2026-11-09

### Fixed
- bump NostalgiaTV app image to 0.10.60-20261109-0110

