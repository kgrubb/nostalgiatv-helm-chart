## [0.2.0] - 2026-09-30

### Added
- support externalTrafficPolicy for MetalLB L2

