## [0.3.9] - 2026-10-18

### Fixed
- bump NostalgiaTV app image to 0.10.29-20261017-2157

