## [0.3.6] - 2026-10-13

### Fixed
- bump NostalgiaTV app image to 0.10.23-20261013-0105

