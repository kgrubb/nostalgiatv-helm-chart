## [0.4.0] - 2026-11-27

### Added
- bump NostalgiaTV app image to 0.11.1-20261127-0054

