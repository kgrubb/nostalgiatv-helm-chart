## [0.3.5] - 2026-10-11

### Fixed
- bump NostalgiaTV app image to 0.10.22-20261010-1812

