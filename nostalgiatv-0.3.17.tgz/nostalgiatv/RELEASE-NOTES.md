## [0.3.17] - 2026-10-30

### Fixed
- bump NostalgiaTV app image to 0.10.49-20261030-0005

