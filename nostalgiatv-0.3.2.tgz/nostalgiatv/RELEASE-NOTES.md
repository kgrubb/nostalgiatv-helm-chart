## [0.3.2] - 2026-10-02

### Fixed
- verify Artifact Hub publisher and use app icon
- use valid Artifact Hub category

