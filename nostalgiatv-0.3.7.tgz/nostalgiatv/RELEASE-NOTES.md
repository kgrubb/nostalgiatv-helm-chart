## [0.3.7] - 2026-10-15

### Fixed
- bump NostalgiaTV app image to 0.10.26-20261015-0010

