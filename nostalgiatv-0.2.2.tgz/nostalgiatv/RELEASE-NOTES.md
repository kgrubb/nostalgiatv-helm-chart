## [0.2.2] - 2026-09-30

### Changed
- drop maintainer-only GPG and Pages bootstrap notes

