## [0.3.22] - 2026-11-06

### Fixed
- bump NostalgiaTV app image to 0.10.55-20261105-0442

