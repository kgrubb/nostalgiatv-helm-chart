## [0.3.20] - 2026-11-02

### Fixed
- bump NostalgiaTV app image to 0.10.53-20261101-1753

