## [0.3.13] - 2026-10-26

### Fixed
- bump NostalgiaTV app image to 0.10.35-20261025-1844

