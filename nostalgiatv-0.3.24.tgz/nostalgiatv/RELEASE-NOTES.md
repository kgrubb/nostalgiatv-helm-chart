## [0.3.24] - 2026-11-08

### Fixed
- bump NostalgiaTV app image to 0.10.57-20261107-1253

