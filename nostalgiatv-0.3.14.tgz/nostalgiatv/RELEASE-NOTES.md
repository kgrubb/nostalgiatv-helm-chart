## [0.3.14] - 2026-10-27

### Fixed
- bump NostalgiaTV app image to 0.10.36-20261027-0039

