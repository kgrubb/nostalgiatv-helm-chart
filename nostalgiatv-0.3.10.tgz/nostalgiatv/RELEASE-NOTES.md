## [0.3.10] - 2026-10-19

### Fixed
- bump NostalgiaTV app image to 0.10.30-20261018-2349

