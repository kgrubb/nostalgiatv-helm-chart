## [0.3.21] - 2026-11-05

### Fixed
- bump NostalgiaTV app image to 0.10.54-20261104-2038

