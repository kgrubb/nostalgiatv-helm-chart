## [0.3.28] - 2026-11-24

### Fixed
- bump NostalgiaTV app image to 0.10.64-20261123-1425

