## [0.3.18] - 2026-10-31

### Fixed
- bump NostalgiaTV app image to 0.10.50-20261030-0542

