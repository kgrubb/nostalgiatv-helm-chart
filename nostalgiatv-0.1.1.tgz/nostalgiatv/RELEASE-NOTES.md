## [0.1.1] - 2026-09-30

### Fixed
- bootstrap first chart release when no tags exist

