## [0.4.1] - 2026-11-28

### Fixed
- bump NostalgiaTV app image to 0.11.2-20261127-2057

