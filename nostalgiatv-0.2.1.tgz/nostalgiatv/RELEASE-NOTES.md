## [0.2.1] - 2026-09-30

### Fixed
- pin upstream image to versioned tag for kube-linter

