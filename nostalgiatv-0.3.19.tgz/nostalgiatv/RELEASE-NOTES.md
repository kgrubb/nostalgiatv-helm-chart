## [0.3.19] - 2026-11-01

### Fixed
- bump NostalgiaTV app image to 0.10.52-20261101-0033

