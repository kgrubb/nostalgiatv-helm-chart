## [0.3.11] - 2026-10-20

### Fixed
- bump NostalgiaTV app image to 0.10.31-20261019-1317

